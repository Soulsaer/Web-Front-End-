let firstcard = 11
let secondcard =12
let cards = [firstcard , secondcard]   // array of list of items
let sum = firstcard + secondcard
let hasblackjack = false
let isAlive = true
let message =" "
let messageEl = document.getElementById("message-el")
let sumEl = document.querySelector("#sum-el")
let cardEl = document.getElementById("card-el")

function startgame()
{
    rendergame()
}
 function rendergame(){
    cardEl.textContent = "Cards:" + cards[0] + " " + cards[1]
    sumEl.textContent = "sum:" + sum
if(sum <= 20)
{
   message = "do you want to draw a new card!"

}
else if (sum === 21 )
{
    message = "you've got a blackjack"
    hasblackjack = true
}
else
{
    message = "you're out of game "
    /* isAlive = False */
}

//cash out 
messageEl.textContent = message
 }

 function newcard()
 { 
    let card = 10 
    cards.push(card)
    sum += card
    startgame();
    console.log("Drawing a new card from the Deck!")
 }