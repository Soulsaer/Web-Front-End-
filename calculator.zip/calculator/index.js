let num1= 3
let num2 =5
let numberEl1 = document.getElementById("num1")
let numberEl2 = document.getElementById("num2")
let signEl = document.getElementById("sign")
let resultEl = document.getElementById("result")
let result=0


function addition() {
  result = 0
  signEl.textContent="+"
  result = num1 + num2
  resultEl.textContent = result
}

function subtraction(){
  result = 0 
    signEl.textContent="-"
    result = num1 - num2 
    resultEl.textContent = result
}

function multiplication(){
  result = 0
  signEl.textContent="*"
  resultEl.textContent = num1 * num2 
}

function division(){
  result = 0
  signEl.textContent="/"
  resultEl.textContent = num1 / num2
}

function Reset(){
  result = 0 
  signEl.texContent=""
  resultEl.textContent= 0
  numberEl1.textContent = 0 
  numberEl2.textContent = 0
}