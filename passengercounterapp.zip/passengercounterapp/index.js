let saveEl = document.getElementById("save-el")
let countel = document.getElementById("countel")
 

 let count = 0
 function increment(){
   count += 1
   countel.textContent=count
 }
 
 function save(){
  let entry = count + " - "
  saveEl.textContent += entry 
  count = 0
  countel.textContent = count
}

