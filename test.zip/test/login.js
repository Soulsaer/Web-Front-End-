
function validateform()
{
    var email = document.getElementById('Email').value;
    var password = document.getElementById('password-el').value;

    if(email === ""  || email == null)
    {
        document.getElementById('Email-error').innerHTML = "*Enter a valid email";
        return false;
    }  
    if(password == "" || password < 8 )
    {
        document.getElementById('passerr').innerHTML = "*Enter a valid password";
        return false; 
    }
    else
    {
        alert("Logged-in successfully");
    }
    return true 
}