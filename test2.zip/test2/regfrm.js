/* var name = document.getElementById('fname').value;
    var email = document.getElementById('Email').value;
    var password = document.getElementById('password').value;
    var cpass = document.getElementById('cpassword').value; */
    
function validateform()
{
    var name = document.getElementById('fname').value;
    var email = document.getElementById('Email').value;
    var password = document.getElementById('password').value;
    var cpass = document.getElementById('cpassword').value;
    
    if(name == "" || name == null || name <2)
    {
        var nameEl = document.getElementById('error').innerHTML = "*Name cannot be empty"
        return false;
    }
    if(email == "" || email == null )
    {
        var emailEl = document.getElementById('error').innerHTML = "*Enter a valid email"
        return false;
    }
    if(password == "" || password == null || password <8)
    {
        var passwordEl = document.getElementById('error').innerHTML = "*Minimum 8 digit password"
        return false;
    }
    if(cpass == "" || cpass == null || cpass != password)
    {
        var cpassEl = document.getElementById('error').innerHTML = "*passwords doesn't match"
        return false;
    }
    return true;
}